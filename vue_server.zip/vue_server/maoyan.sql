SET NAMES UTF8;
DROP DATABASE IF EXISTS maoyan;
CREATE DATABASE maoyan CHARSET=UTF8;
USE maoyan
CREATE TABLE movie(
    id INT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(50),
    movie_type VARCHAR(32),
    movie_review VARCHAR(100),
    actor VARCHAR(50),
    film_comment VARCHAR(1000),
    show_time DATE
);